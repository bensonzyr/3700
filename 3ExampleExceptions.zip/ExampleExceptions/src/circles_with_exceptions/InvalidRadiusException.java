package circles_with_exceptions;

public class InvalidRadiusException extends Exception {
	InvalidRadiusException(String s) {
		super(s);
	}
}
