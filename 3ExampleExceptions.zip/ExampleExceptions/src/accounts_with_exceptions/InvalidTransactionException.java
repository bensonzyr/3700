package accounts_with_exceptions;

public class InvalidTransactionException extends Exception {
	InvalidTransactionException(String s) {
		super(s);
	}
}
